#include <libc/misc/internals/__errno_location.c>
